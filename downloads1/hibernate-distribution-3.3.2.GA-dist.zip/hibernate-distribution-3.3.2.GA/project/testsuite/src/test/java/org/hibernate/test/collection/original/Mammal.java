package org.hibernate.test.collection.original;

public class Mammal extends Animal {
    private String mammalName;
    private String mammalName2;
    private String mammalName3;

	public String getMammalName() {
		return mammalName;
	}

	public void setMammalName(String mammalName) {
		this.mammalName = mammalName;
	}

	public String getMammalName2() {
		return mammalName2;
	}

	public void setMammalName2(String mammalName2) {
		this.mammalName2 = mammalName2;
	}

	public String getMammalName3() {
		return mammalName3;
	}

	public void setMammalName3(String mammalName3) {
		this.mammalName3 = mammalName3;
	}
	
	

}