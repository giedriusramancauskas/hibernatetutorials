package org.hibernate.test.mappingexception;

public class InvalidMapping {
// This Class Intentionally Left Blank
}
