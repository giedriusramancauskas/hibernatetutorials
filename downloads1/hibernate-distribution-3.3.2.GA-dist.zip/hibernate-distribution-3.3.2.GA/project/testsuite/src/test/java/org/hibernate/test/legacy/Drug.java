package org.hibernate.test.legacy;

/**
 * @author hbm2java
 */
public class Drug extends org.hibernate.test.legacy.Resource {

   java.lang.String id;


  java.lang.String getId() {
    return id;
  }

  void  setId(java.lang.String newValue) {
    id = newValue;
  }


}
