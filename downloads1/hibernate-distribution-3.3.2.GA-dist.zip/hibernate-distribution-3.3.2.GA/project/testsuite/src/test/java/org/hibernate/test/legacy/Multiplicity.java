//$Id: Multiplicity.java 4599 2004-09-26 05:18:27Z oneovthafew $
package org.hibernate.test.legacy;

import java.io.Serializable;

public class Multiplicity implements Serializable {
	public int count;
	public GlarchProxy glarch;
}
